#ifndef INTEGRATION_H
#define INTEGRATION_H

template <typename T, typename F>
void integrate2d(unsigned int blocks, unsigned int threads,
								 T start, T delta, unsigned int iterations, T * result);

#endif
